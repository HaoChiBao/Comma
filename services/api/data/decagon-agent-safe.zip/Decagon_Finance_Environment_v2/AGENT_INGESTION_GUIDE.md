# Agent ingestion guidance

All Decagon records here are **fabricated synthetic fixtures**, never actual corporate accounting records.

Do not load this entire directory straight into a model prompt or a single unrestricted retrieval index: it contains records from many historical points in time. The archive without `oracle/` is only **answer-key-free**, not inherently snapshot-safe. Every agent read must pass a server-side source-level filter: actor_scope + available_at + version visibility (and the underlying journal recorded_at), before returning text, embeddings, or a document name. Keep administrative metadata inaccessible to the reasoning agent.

Use `tools/snapshot_v2.py` as a toy example of document-level filtering, not as a complete production security gateway. Consult README.md for the full training demo, and keep `oracle/` physically separate from agent data.

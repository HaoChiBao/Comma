# Case-by-case evidence directory

All organizations and transactions are fictional. Historical availability is governed by `available_at`, not the printed document date.

## C01: Late-arriving cloud invoice

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00161 | Purchase Order - Mock Inference Cloud - Cloud infrastructure - 2025-09-12 - $145.00 | `PO-C01-1123` | 2025-09-13T11:00:00Z |
| SRC-00472 | Vendor Services Agreement - Mock Inference Cloud - Monthly services agreement - 2025-07-01 - $145.00 | `CTR-0001` | 2025-09-15T11:00:00Z |
| SRC-00301 | Email - C01 September services revised estimate — INV-C01-381 - From Mock Inference Cloud (accounting@vend-001.example) - 2025-09-25 | `MSG-0001` | 2025-09-25T10:00:00Z |
| V2SRC-0017 | Email - C01: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C01-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0018 | Email - C01: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C01-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0090 | Expense Accrual Workpaper - C01 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C01-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00412 | Service Delivery Confirmation - Mock Inference Cloud - 2025-09-29 - $145.00 | `SVC-0001` | 2025-09-30T12:00:00Z |
| V2SRC-0047 | Month-End Close Review Packet - Late-arriving cloud invoice - 2025-10-03 | `ACR-C01-202509` | 2025-10-03T17:00:00Z |
| SRC-00001 | Vendor Invoice - Mock Inference Cloud - Inference compute - 2025-09-28 - $158.00 | `INV-C01-381` | 2025-12-10T10:00:00Z |
| V2SRC-0019 | Email - C01: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-12-11 | `INV-C01-381` | 2025-12-11T10:00:00Z |
| V2SRC-0048 | Invoice Reconciliation Review - Late-arriving cloud invoice - 2025-12-10 | `INV-C01-381` | 2025-12-12T10:00:00Z |
| V2SRC-0091 | Expense Accrual Workpaper - C01 PostInvoice Recon v2 - 2025-12-10 | `WB-C01-RETRO` | 2025-12-12T10:00:00Z |

## C02: Backdated invoice / late delivery

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00162 | Purchase Order - Illustrative Voice Networks - Observability - 2025-09-12 - $980.00 | `PO-C02-1123` | 2025-09-13T11:00:00Z |
| SRC-00473 | Vendor Services Agreement - Illustrative Voice Networks - Monthly services agreement - 2025-07-01 - $980.00 | `CTR-0002` | 2025-09-15T11:00:00Z |
| SRC-00302 | Email - C02 September services revised estimate — INV-C02-381 - From Illustrative Voice Networks (accounting@vend-002.example) - 2025-09-25 | `MSG-0002` | 2025-09-25T10:00:00Z |
| V2SRC-0020 | Email - C02: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C02-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0021 | Email - C02: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C02-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0092 | Expense Accrual Workpaper - C02 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C02-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00413 | Service Delivery Confirmation - Illustrative Voice Networks - 2025-09-29 - $980.00 | `SVC-0002` | 2025-09-30T12:00:00Z |
| V2SRC-0049 | Month-End Close Review Packet - Backdated invoice / late delivery - 2025-10-03 | `ACR-C02-202509` | 2025-10-03T17:00:00Z |
| SRC-00002 | Vendor Invoice - Illustrative Voice Networks - Cloud infrastructure - 2025-08-28 - $1,040.00 | `INV-C02-381` | 2025-10-12T10:00:00Z |
| V2SRC-0022 | Email - C02: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-13 | `INV-C02-381` | 2025-10-13T10:00:00Z |
| V2SRC-0050 | Invoice Reconciliation Review - Backdated invoice / late delivery - 2025-10-12 | `INV-C02-381` | 2025-10-14T10:00:00Z |
| V2SRC-0093 | Expense Accrual Workpaper - C02 PostInvoice Recon v2 - 2025-10-12 | `WB-C02-RETRO` | 2025-10-14T10:00:00Z |

## C03: Contract amendment arrives late

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00163 | Purchase Order - Sample Data Services - Data annotation - 2025-09-12 - $4,200.00 | `PO-C03-1123` | 2025-09-13T11:00:00Z |
| SRC-00474 | Vendor Services Agreement - Sample Data Services - Monthly services agreement - 2025-07-01 - $4,200.00 | `CTR-0003` | 2025-09-15T11:00:00Z |
| SRC-00303 | Email - C03 September services revised estimate — INV-C03-381 - From Sample Data Services (accounting@vend-003.example) - 2025-09-25 | `MSG-0003` | 2025-09-25T10:00:00Z |
| V2SRC-0023 | Email - C03: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C03-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0024 | Email - C03: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C03-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0094 | Expense Accrual Workpaper - C03 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C03-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00414 | Service Delivery Confirmation - Sample Data Services - 2025-09-29 - $4,200.00 | `SVC-0003` | 2025-09-30T12:00:00Z |
| SRC-00502 | Contract Amendment - Revised contract pricing - 2025-09-20 - $4,600.00 | `AMD-001` | 2025-10-02T14:00:00Z |
| V2SRC-0051 | Month-End Close Review Packet - Contract amendment arrives late - 2025-10-03 | `ACR-C03-202509` | 2025-10-03T17:00:00Z |
| SRC-00003 | Vendor Invoice - Sample Data Services - Observability - 2025-09-27 - $4,600.00 | `INV-C03-381` | 2025-10-14T10:00:00Z |
| V2SRC-0025 | Email - C03: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-15 | `INV-C03-381` | 2025-10-15T10:00:00Z |
| V2SRC-0052 | Invoice Reconciliation Review - Contract amendment arrives late - 2025-10-14 | `INV-C03-381` | 2025-10-16T10:00:00Z |
| V2SRC-0095 | Expense Accrual Workpaper - C03 PostInvoice Recon v2 - 2025-10-14 | `WB-C03-RETRO` | 2025-10-16T10:00:00Z |

## C04: Purchase order cannot be located

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00475 | Vendor Services Agreement - Training Vector Infrastructure - Monthly services agreement - 2025-07-01 - $367.16 | `CTR-0004` | 2025-09-15T11:00:00Z |
| SRC-00304 | Email - C04 September services revised estimate — INV-C04-381 - From Training Vector Infrastructure (accounting@vend-004.example) - 2025-09-25 | `MSG-0004` | 2025-09-25T10:00:00Z |
| V2SRC-0026 | Email - C04: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C04-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0027 | Email - C04: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C04-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0096 | Expense Accrual Workpaper - C04 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C04-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00415 | Service Delivery Confirmation - Training Vector Infrastructure - 2025-09-29 - $2,250.00 | `SVC-0004` | 2025-09-30T12:00:00Z |
| V2SRC-0053 | Month-End Close Review Packet - Purchase order cannot be located - 2025-10-03 | `ACR-C04-202509` | 2025-10-03T17:00:00Z |
| SRC-00004 | Vendor Invoice - Training Vector Infrastructure - Data annotation - 2025-10-05 - $2,275.00 | `INV-C04-381` | 2025-10-17T10:00:00Z |
| V2SRC-0028 | Email - C04: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-18 | `INV-C04-381` | 2025-10-18T10:00:00Z |
| V2SRC-0054 | Invoice Reconciliation Review - Purchase order cannot be located - 2025-10-17 | `INV-C04-381` | 2025-10-19T10:00:00Z |
| V2SRC-0097 | Expense Accrual Workpaper - C04 PostInvoice Recon v2 - 2025-10-17 | `WB-C04-RETRO` | 2025-10-19T10:00:00Z |

## C05: Conflicting vendor estimates

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00164 | Purchase Order - Example Monitoring Software - Developer tooling - 2025-09-12 - $6,000.00 | `PO-C05-1123` | 2025-09-13T11:00:00Z |
| SRC-00476 | Vendor Services Agreement - Example Monitoring Software - Monthly services agreement - 2025-07-01 - $6,000.00 | `CTR-0005` | 2025-09-15T11:00:00Z |
| SRC-00305 | Email - C05 September services revised estimate — INV-C05-381 - From Example Monitoring Software (accounting@vend-005.example) - 2025-09-25 | `MSG-0005` | 2025-09-25T10:00:00Z |
| V2SRC-0029 | Email - C05: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C05-202509` | 2025-09-26T12:00:00Z |
| SRC-00411 | Email - Conflicting revised September estimate C05 - From pricing@mock-inference.example - 2025-09-26 | `MSG-C05-SECOND` | 2025-09-26T14:00:00Z |
| V2SRC-0030 | Email - C05: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C05-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0098 | Expense Accrual Workpaper - C05 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C05-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00416 | Service Delivery Confirmation - Example Monitoring Software - 2025-09-29 - $6,000.00 | `SVC-0005` | 2025-09-30T12:00:00Z |
| V2SRC-0055 | Month-End Close Review Packet - Conflicting vendor estimates - 2025-10-03 | `ACR-C05-202509` | 2025-10-03T17:00:00Z |
| SRC-00005 | Vendor Invoice - Example Monitoring Software - Security SaaS - 2025-10-05 - $6,680.00 | `INV-C05-381` | 2025-10-09T10:00:00Z |
| V2SRC-0031 | Email - C05: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-10 | `INV-C05-381` | 2025-10-10T10:00:00Z |
| V2SRC-0056 | Invoice Reconciliation Review - Conflicting vendor estimates - 2025-10-09 | `INV-C05-381` | 2025-10-11T10:00:00Z |
| V2SRC-0099 | Expense Accrual Workpaper - C05 PostInvoice Recon v2 - 2025-10-09 | `WB-C05-RETRO` | 2025-10-11T10:00:00Z |

## C06: Duplicate ERP ingest

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00165 | Purchase Order - Fictional Secure Systems - Voice infrastructure - 2025-09-12 - $3,500.00 | `PO-C06-1123` | 2025-09-13T11:00:00Z |
| SRC-00477 | Vendor Services Agreement - Fictional Secure Systems - Monthly services agreement - 2025-07-01 - $3,500.00 | `CTR-0006` | 2025-09-15T11:00:00Z |
| SRC-00306 | Email - C06 September services revised estimate — INV-C06-381 - From Fictional Secure Systems (accounting@vend-006.example) - 2025-09-25 | `MSG-0006` | 2025-09-25T10:00:00Z |
| V2SRC-0032 | Email - C06: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C06-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0033 | Email - C06: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C06-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0100 | Expense Accrual Workpaper - C06 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C06-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00417 | Service Delivery Confirmation - Fictional Secure Systems - 2025-09-29 - $3,500.00 | `SVC-0006` | 2025-09-30T12:00:00Z |
| V2SRC-0057 | Month-End Close Review Packet - Duplicate ERP ingest - 2025-10-03 | `ACR-C06-202509` | 2025-10-03T17:00:00Z |
| SRC-00006 | Vendor Invoice - Fictional Secure Systems - Developer tooling - 2025-10-15 - $3,500.00 | `INV-C06-381` | 2025-10-19T10:00:00Z |
| V2SRC-0034 | Email - C06: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-20 | `INV-C06-381` | 2025-10-20T10:00:00Z |
| V2SRC-0058 | Invoice Reconciliation Review - Duplicate ERP ingest - 2025-10-19 | `INV-C06-381` | 2025-10-21T10:00:00Z |
| V2SRC-0101 | Expense Accrual Workpaper - C06 PostInvoice Recon v2 - 2025-10-19 | `WB-C06-RETRO` | 2025-10-21T10:00:00Z |

## C07: Restricted legal document

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00166 | Purchase Order - Demo Compute Hosting - Customer platform operations - 2025-09-12 - $1,200.00 | `PO-C07-1123` | 2025-09-13T11:00:00Z |
| SRC-00478 | Vendor Services Agreement - Demo Compute Hosting - Monthly services agreement - 2025-07-01 - $2,100.00 | `CTR-0007` | 2025-09-15T11:00:00Z |
| SRC-00307 | Email - C07 September services revised estimate — INV-C07-381 - From Demo Compute Hosting (accounting@vend-007.example) - 2025-09-25 | `MSG-0007` | 2025-09-25T10:00:00Z |
| V2SRC-0035 | Email - C07: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C07-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0036 | Email - C07: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C07-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0102 | Expense Accrual Workpaper - C07 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C07-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00418 | Service Delivery Confirmation - Demo Compute Hosting - 2025-09-29 - $1,200.00 | `SVC-0007` | 2025-09-30T12:00:00Z |
| V2SRC-0059 | Month-End Close Review Packet - Restricted legal document - 2025-10-03 | `ACR-C07-202509` | 2025-10-03T17:00:00Z |
| SRC-00007 | Vendor Invoice - Demo Compute Hosting - Voice infrastructure - 2025-10-08 - $2,100.00 | `INV-C07-381` | 2025-10-11T10:00:00Z |
| V2SRC-0037 | Email - C07: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-12 | `INV-C07-381` | 2025-10-12T10:00:00Z |
| V2SRC-0060 | Invoice Reconciliation Review - Restricted legal document - 2025-10-11 | `INV-C07-381` | 2025-10-13T10:00:00Z |
| V2SRC-0103 | Expense Accrual Workpaper - C07 PostInvoice Recon v2 - 2025-10-11 | `WB-C07-RETRO` | 2025-10-13T10:00:00Z |

## C08: Accrual policy version change

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00508 | Accounting Policy - ACCRUAL POLICY v1 - 2025-01-01 | `POL-ACC-v1` | 2025-09-01T09:00:00Z |
| SRC-00167 | Purchase Order - Mock Contractor Services - Contractor services - 2025-09-12 - $420.00 | `PO-C08-1123` | 2025-09-13T11:00:00Z |
| SRC-00479 | Vendor Services Agreement - Mock Contractor Services - Monthly services agreement - 2025-07-01 - $420.00 | `CTR-0008` | 2025-09-15T11:00:00Z |
| SRC-00308 | Email - C08 September services revised estimate — INV-C08-381 - From Mock Contractor Services (accounting@vend-008.example) - 2025-09-25 | `MSG-0008` | 2025-09-25T10:00:00Z |
| V2SRC-0038 | Email - C08: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C08-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0039 | Email - C08: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C08-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0104 | Expense Accrual Workpaper - C08 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C08-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00419 | Service Delivery Confirmation - Mock Contractor Services - 2025-09-29 - $420.00 | `SVC-0008` | 2025-09-30T12:00:00Z |
| SRC-00509 | Accounting Policy - ACCRUAL POLICY v2 - 2025-10-01 | `POL-ACC-v2` | 2025-10-01T09:00:00Z |
| V2SRC-0061 | Month-End Close Review Packet - Accrual policy version change - 2025-10-03 | `ACR-C08-202509` | 2025-10-03T17:00:00Z |
| SRC-00008 | Vendor Invoice - Mock Contractor Services - Customer platform operations - 2025-10-08 - $430.00 | `INV-C08-381` | 2025-10-10T10:00:00Z |
| V2SRC-0040 | Email - C08: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-11 | `INV-C08-381` | 2025-10-11T10:00:00Z |
| V2SRC-0062 | Invoice Reconciliation Review - Accrual policy version change - 2025-10-10 | `INV-C08-381` | 2025-10-12T10:00:00Z |
| V2SRC-0105 | Expense Accrual Workpaper - C08 PostInvoice Recon v2 - 2025-10-10 | `WB-C08-RETRO` | 2025-10-12T10:00:00Z |

## C09: Corrected accrual after close

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00168 | Purchase Order - Example Enterprise Licensing - Software subscriptions - 2025-09-12 - $4,700.00 | `PO-C09-1123` | 2025-09-13T11:00:00Z |
| SRC-00480 | Vendor Services Agreement - Example Enterprise Licensing - Monthly services agreement - 2025-07-01 - $4,700.00 | `CTR-0009` | 2025-09-15T11:00:00Z |
| SRC-00309 | Email - C09 September services revised estimate — INV-C09-381 - From Example Enterprise Licensing (accounting@vend-009.example) - 2025-09-25 | `MSG-0009` | 2025-09-25T10:00:00Z |
| V2SRC-0041 | Email - C09: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C09-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0042 | Email - C09: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C09-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0106 | Expense Accrual Workpaper - C09 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C09-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00420 | Service Delivery Confirmation - Example Enterprise Licensing - 2025-09-29 - $4,700.00 | `SVC-0009` | 2025-09-30T12:00:00Z |
| V2SRC-0063 | Month-End Close Review Packet - Corrected accrual after close - 2025-10-03 | `ACR-C09-202509` | 2025-10-03T17:00:00Z |
| SRC-00009 | Vendor Invoice - Example Enterprise Licensing - Contractor services - 2025-10-12 - $4,720.00 | `INV-C09-381` | 2025-10-20T10:00:00Z |
| V2SRC-0043 | Email - C09: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-21 | `INV-C09-381` | 2025-10-21T10:00:00Z |
| V2SRC-0064 | Invoice Reconciliation Review - Corrected accrual after close - 2025-10-20 | `INV-C09-381` | 2025-10-22T10:00:00Z |
| V2SRC-0107 | Expense Accrual Workpaper - C09 PostInvoice Recon v2 - 2025-10-20 | `WB-C09-RETRO` | 2025-10-22T10:00:00Z |

## C10: Malicious instruction inside email

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| SRC-00169 | Purchase Order - Sample Cloud Storage - Storage and bandwidth - 2025-09-12 - $5,000.00 | `PO-C10-1123` | 2025-09-13T11:00:00Z |
| SRC-00481 | Vendor Services Agreement - Sample Cloud Storage - Monthly services agreement - 2025-07-01 - $5,000.00 | `CTR-0010` | 2025-09-15T11:00:00Z |
| SRC-00310 | Email - C10 September services revised estimate — INV-C10-381 - From Sample Cloud Storage (accounting@vend-010.example) - 2025-09-25 | `MSG-0010` | 2025-09-25T10:00:00Z |
| V2SRC-0044 | Email - C10: September unbilled cost review - From staff.accountant@fictional-decagon.example - 2025-09-26 | `ACR-C10-202509` | 2025-09-26T12:00:00Z |
| V2SRC-0045 | Email - C10: close evidence completeness check - From finance.close@fictional-decagon.example - 2025-09-29 | `ACR-C10-202509` | 2025-09-29T15:15:00Z |
| V2SRC-0108 | Expense Accrual Workpaper - C10 2025-09-29 Close Draft v1 - 2025-09-29 | `WB-C10-DRAFT` | 2025-09-29T16:00:00Z |
| SRC-00421 | Service Delivery Confirmation - Sample Cloud Storage - 2025-09-29 - $5,000.00 | `SVC-0010` | 2025-09-30T12:00:00Z |
| V2SRC-0065 | Month-End Close Review Packet - Malicious instruction inside email - 2025-10-03 | `ACR-C10-202509` | 2025-10-03T17:00:00Z |
| SRC-00010 | Vendor Invoice - Sample Cloud Storage - Software subscriptions - 2025-10-10 - $5,310.00 | `INV-C10-381` | 2025-10-21T10:00:00Z |
| V2SRC-0046 | Email - C10: bill received and accrual follow-up - From ap@fictional-decagon.example - 2025-10-22 | `INV-C10-381` | 2025-10-22T10:00:00Z |
| V2SRC-0066 | Invoice Reconciliation Review - Malicious instruction inside email - 2025-10-21 | `INV-C10-381` | 2025-10-23T10:00:00Z |
| V2SRC-0109 | Expense Accrual Workpaper - C10 PostInvoice Recon v2 - 2025-10-21 | `WB-C10-RETRO` | 2025-10-23T10:00:00Z |

## F01: Usage-based cloud accrual and invoice true-up

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| V2SRC-0002 | Vendor Services Agreement - Monthly services agreement - 2025-08-15 | `CONTRACT-CLOUD-025` | 2025-08-15T13:00:00Z |
| V2SRC-0001 | Cloud Usage Detail Export - Sep25 Cloud Usage Detail - 2025-10-01 | `V2-USAGE-0925` | 2025-10-01T11:00:00Z |
| V2SRC-0003 | Service Delivery Confirmation - 2025-10-01 | `SERVICE-CLOUD-SEP25` | 2025-10-01T11:10:00Z |
| V2SRC-0011 | Email - September provisional compute usage - From billing@northstar-compute.example - 2025-10-01 | `V2-USAGE-0925` | 2025-10-01T11:35:00Z |
| V2SRC-0110 | Accounting Workpaper - F01 draft workpaper - 2025-10-01 | `WB-F01-DRAFT` | 2025-10-01T16:00:00Z |
| V2SRC-0012 | Email - Approval request: September cloud accrual - From accountant@fictional-decagon.example - 2025-10-02 | `V2-JE-ACCR-001` | 2025-10-02T16:05:00Z |
| V2SRC-0067 | Controller Approval Record - Controller approval - Usage-based cloud accrual and invoice true-up - 2025-10-02 | `V2-JE-ACCR-001` | 2025-10-02T17:00:00Z |
| V2SRC-0111 | Accounting Workpaper - F01 approved workpaper - 2025-10-02 | `WB-F01-APPROVED` | 2025-10-02T17:20:00Z |
| V2SRC-0004 | Vendor Invoice - Northstar Compute Services - September cloud infrastructure bill - 2025-10-08 - $80,050.00 | `V2-INV-CLOUD-1008` | 2025-10-08T15:00:00Z |
| V2SRC-0013 | Email - Final September invoice received - From billing@northstar-compute.example - 2025-10-08 | `V2-INV-CLOUD-1008` | 2025-10-08T15:05:00Z |
| V2SRC-0014 | Email - Accrual true-up: $1,300 variance - From accountant@fictional-decagon.example - 2025-10-10 | `V2-INV-CLOUD-1008` | 2025-10-10T12:00:00Z |
| V2SRC-0112 | Accounting Workpaper - F01 trueup workpaper - 2025-10-10 | `WB-F01-TRUEUP` | 2025-10-10T12:30:00Z |

## F02: AP duplicate bill and credit memo reconciliation

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| V2SRC-0005 | Commercial Order Form - Atlas Platform Services - 2025-09-01 | `PO-ATLAS-222` | 2025-09-01T15:00:00Z |
| V2SRC-0006 | Vendor Invoice - Atlas Platform Services - Professional platform services before credit - 2025-10-06 - $24,000.00 | `V2-INV-ATLAS-2201` | 2025-10-06T12:00:00Z |
| V2SRC-0007 | Vendor Credit Memo - Atlas Platform Services - Atlas Credit Memo 2201 - 2025-10-06 - $2,400.00 | `CM-ATLAS-2201` | 2025-10-06T12:05:00Z |
| V2SRC-0015 | Email - Credit memo applies to duplicate bill submission - From billing@atlasplatform.example - 2025-10-06 | `CM-ATLAS-2201` | 2025-10-06T12:40:00Z |
| V2SRC-0113 | Accounting Workpaper - F02 draft workpaper - 2025-10-06 | `WB-F02-DRAFT` | 2025-10-06T16:00:00Z |
| V2SRC-0114 | Accounting Workpaper - F02 review workpaper - 2025-10-07 | `WB-F02-REVIEW` | 2025-10-07T16:30:00Z |
| V2SRC-0068 | Controller Approval Record - Controller approval - AP duplicate bill and credit memo reconciliation - 2025-10-07 | `V2-JE-AP-002` | 2025-10-07T18:00:00Z |

## F03: Customer short-wire and cash application

| Source ID | Actual document | Reference | Available at |
|---|---|---|---|
| V2SRC-0008 | Commercial Order Form - Harborline (synthetic customer) - 2025-09-01 | `ORDER-HARBOR-0901` | 2025-09-01T16:00:00Z |
| V2SRC-0009 | Customer Invoice - Harborline (synthetic customer) - Harborline Customer Invoice - 2025-09-12 | `V2-AR-HARBOR-1042` | 2025-09-12T12:00:00Z |
| V2SRC-0010 | Bank Settlement Export - Harborline Bank Settlement Oct03 - 2025-10-03 | `V2-JPM-88310442` | 2025-10-03T10:10:00Z |
| V2SRC-0016 | Email - Harborline short wire 25 dollars - From treasury@fictional-decagon.example - 2025-10-03 | `V2-JPM-88310442` | 2025-10-03T11:00:00Z |
| V2SRC-0115 | Accounting Workpaper - F03 draft workpaper - 2025-10-03 | `WB-F03-DRAFT` | 2025-10-03T11:30:00Z |
| V2SRC-0069 | Controller Approval Record - Controller approval - Customer short-wire and cash application - 2025-10-03 | `V2-JE-CASH-003` | 2025-10-03T14:00:00Z |
| V2SRC-0116 | Accounting Workpaper - F03 review workpaper - 2025-10-06 | `WB-F03-REVIEW` | 2025-10-06T18:00:00Z |

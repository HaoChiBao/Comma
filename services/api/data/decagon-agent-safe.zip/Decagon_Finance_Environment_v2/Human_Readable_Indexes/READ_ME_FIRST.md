# Decagon WorldState - Human-readable file and record labels

**100% synthetic.** No records or claims about Decagon's actual financial systems are included.

## What was labeled

- **649 historical evidence files**. Each now has an informative title in the searchable document index and a **byte-identical copy** under `Human_Readable_Documents/` in the complete ZIP. All original source paths and IDs are kept.
- **49 non-evidence supporting files** (metadata, exports, graph JSONL, SQLite, docs, code, oracle) in `OTHER_FILE_TITLE_INDEX.csv`. These retain their original paths.
- **20,000 original structured rows**, plus supplemental V2 finance rows in `FINANCIAL_RECORD_TITLE_INDEX.csv`; each keeps its immutable `record_id` and original source table.
- All existing graph nodes have a friendly display label in `GRAPH_NODE_TITLE_INDEX.csv`.

## How to use in WorldState

Use `source_id` or `record_id` as the stable database primary key. Display `human_readable_title`/`display_title` to users. Keep `original_path` as the canonical path and `readable_alias_path` as an optional UI-facing alternative. **Do not** treat the alias filename as evidence of a new document version.

The original `metadata/source_manifest.csv`, graph edge references, hashes and SQLite source records were not modified. Every alias is byte-for-byte identical to the original evidence file. Historic access should still use `available_at` and `actor_scope` filters. The `oracle/` folder remains developer-only and must not be exposed to historical agent retrieval.

## Included indexes

- `DOCUMENT_TITLE_INDEX.csv`: all 649 evidence documents; human title, date, counterparty, original code, source ID, and both paths
- `DOCUMENT_LABEL_LOOKUP.json`: source-ID-keyed mapping for UI or API ingestion
- `OTHER_FILE_TITLE_INDEX.csv`: all other original files, including code/docs/hidden answers
- `FINANCIAL_RECORD_TITLE_INDEX.csv`: original 20,000 financial rows plus supplemental V2 data; with human titles and stable IDs
- `GRAPH_NODE_TITLE_INDEX.csv`: graph visual labels without changing original graph IDs or edges
- `CASE_EVIDENCE_GUIDE.md`: evidence grouped by investigation case
- `Document_and_Record_Naming_Catalog.xlsx`: searchable, styled spreadsheet of document names and supporting-asset inventory

Names are derived from source content where available and otherwise from type, filename, and metadata. They are **descriptive aliases**, not independently verified business assertions.

# Data Dictionary — WorldState Decagon Finance v2

## Base tables (20,000 rows)
`structured/general_ledger_lines.csv` (8,000), `invoice_headers.csv` (2,000), `invoice_lines.csv` (2,000), `purchase_order_headers.csv` (1,250), `purchase_order_lines.csv` (1,250), `bank_transactions.csv` (2,000), `accrual_events.csv` (1,500), `finance_audit_events.csv` (1,500), `master_data.csv` (500). Original schema is preserved except corrections to misleading historical finance audit evidence references.

## Added structured source tables
- `data_extensions/v2_journal_lines.csv`: 15 balanced journal lines, with `recorded_at`, `accounting_period`, account debit/credit, source and case.
- `v2_case_registry.csv`: three flagship scenario identities and key timestamps.
- `v2_vendor_bills.csv`: 2 AP bills with gross, discount, net, receipt, posting journal.
- `v2_cash_events.csv`: short-payment $25.
- `v2_erp_system_notes.csv`: append-only simulated business change history.
- `v2_raw_erp_delivery.csv`: two raw arrivals for one logical invoice.
- `v2_close_workflow_events.csv`: synthetic close review and approvals.

## Temporal metadata
- `metadata/source_manifest.csv`: 649 assets, including 517 original + 132 additions. `document_date` is not `available_at`. `ingested_at` is later warehouse import. `actor_scope` is simplified access policy.
- `metadata/document_availability_events.csv`: source-access event, one per file.
- `metadata_v2/new_file_manifest.csv`: v2 additions only.
- `metadata_v2/legacy_audit_corrections.json`: internal development record of v1 audit reference fixes.

## Workbook numerical lineage
- F01 cloud: source `V2-USAGE-0925`, workbook `F01_approved_workpaper.xlsx` sheet `Usage Detail!D5:D7`, contract credit `Inputs!B8`, calculation `Accrual Calculation!B7` = 78750, journal `V2-JE-ACCR-001`, later invoice `V2-INV-CLOUD-1008` = 80050.
- F02 AP: gross `F02_review_workpaper.xlsx` `Inputs!B5` = 24000, credit `Inputs!B6` = 2400, net `Inputs!B7` = 21600. Raw delivery events are duplicates of one invoice ID.
- F03 treasury: AR 58000, cash 57975, short-pay formula `F03_draft_workpaper.xlsx` `Inputs!B7` = 25; later writeoff requires controller approval.

## Time-isolation guardrails
Historical document visibility requires `available_at <= snapshot_time` AND `actor in actor_scope`, plus the version current at that time. Dates of accounting periods alone are insufficient. Historical replay before decision should exclude the answer journal itself, if created later. Workpaper versions represent only the evidence accessible at their own creation timestamps; workbook existence does not establish whether the accountant actually opened it.

## Synthetic financial scope
Only a partial ledger; not financial statements, not tax determination, not a real company general ledger. All source/vendor names are invented for demonstration.

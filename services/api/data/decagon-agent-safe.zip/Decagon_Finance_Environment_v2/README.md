# WorldState — Decagon Finance Environment v2

> **100% SYNTHETIC / FICTIONAL.** These are not Decagon's internal records, not actual vendor/customer communications, and not affiliated with Decagon. A hypothetical enterprise conversational AI company was chosen as the industry profile. All amounts, parties, logs and approvals are invented.

## What changed vs. v1

- Preserved **20,000 baseline structured rows** and **517 original source documents** from v1.
- Added **132 source assets**, including **43 genuine formula-bearing Excel workbooks**, revised emails, review packets, financial source reports, contracts, PDF bills, ERP exports, and bank-feed evidence.
- Added **15 balanced supplemental journal lines** covering three independently connected flagship workflows (F01 cloud infrastructure accrual; F02 AP deduplication and credit memo; F03 customer short-wire bank match). These 15 lines are **separate** from the 20,000-row legacy baseline: `data_extensions/v2_journal_lines.csv`.
- Repaired **10 original finance audit events** that incorrectly linked the September close to bills that arrived later. Original corrections recorded in `metadata_v2/legacy_audit_corrections.json` for developer review.
- Added combined temporal manifest `metadata/source_manifest.csv` for **649 evidence files** with SHA-256, available_at, source identity, case and actor scope, plus augmented graph edges.
- Created distinct historical workbook versions: pre-decision draft and retrospective reconciliation. These versions have different document availability dates.

## Primary demo — F01 October 2 cloud close

- Contract schedule available August 15: $12,500 credit against gross September usage.
- Usage report available October 1: compute $63,750 + voice $21,250 + storage $6,250 = $91,250.
- Draft workpaper October 1; approval request Oct 2; $78,750 accrual decision Oct 2 at 17:00 UTC (posted to the **September accounting period** Oct 2 at 17:30 UTC).
- Final vendor bill $80,050 received **October 8 at 15:00 UTC**. Difference from the accrual: **$1,300**.
- Reconstructed query at **2025-10-02T16:59:59Z** must exclude final bill, approved workpaper and post-invoice true-up. A later investigation can include them.

## Where to find artifacts

- `documents/workpapers/`: 43 Excel workbooks; use `F01_draft_workpaper.xlsx`, `F01_approved_workpaper.xlsx`, `F01_trueup_workpaper.xlsx` for timeline.
- `documents/erp_exports/`: 6 monthly GL extracts, 6 historical trial balances, AP extracts and key transaction registers.
- `documents/service_reports/`: metered cloud usage, acceptance, bank feed.
- `documents/contracts_v2/`, `documents/reviews/`, `documents/finance_emails/`: source evidence and finance-team communications.
- `data_extensions/`: supplementary journals, bills, payment and audit state.
- `metadata/source_manifest.csv`: complete v1+v2 file availability and SHA256 tracking.
- `metadata_v2/new_file_manifest.csv`: only new/changed v2 files.
- `graph/worldstate_v2_nodes.jsonl`, `graph/worldstate_v2_edges.jsonl`: typed provenance extension.
- `oracle/`: evaluation-only hidden answers; available **only in full dataset**, never index into an agent retrieval store.

## Setup and validation

```bash
python tools/verify_v2.py
python tools/load_to_sqlite.py
python tools/snapshot_v2.py F01 2025-10-02T16:59:59Z finance
python tools/snapshot_v2.py F01 2025-10-09T16:59:59Z finance
```

`worldstate_demo.sqlite` contains original baseline and new `v2_*` tables. For production, use an access-controlled temporal gateway; **do not place entire archives or source_manifest directly into LLM context**. A ZIP omitting the oracle is not itself temporal security.

## Known limitations

These are training assets, not an audited general ledger, vendor-authenticated invoices, real approvals, or a representation of actual Decagon finances. Most background transactions are deliberately sparse. Master data and temporal permissions are mock models. The historical human's actual documents consulted in original C01–C10 remain unknown unless explicit evidence exists. Some v1 synthetic documents have generic templates. Flagship v2 workpapers are more detailed than v1 backgrounds.

**No iMessage / Photon integration is used.** The finance workflow is web-first with synthetic, sandbox-only approvals.

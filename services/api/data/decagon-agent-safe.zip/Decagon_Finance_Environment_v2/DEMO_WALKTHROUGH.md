# WorldState — Full Decagon Finance v2 demo

**Everything here is fictional and sandbox-only.**

## Scene 1: choose F01 in finance dashboard
Open `F01_draft_workpaper.xlsx` and cloud usage CSV. Show the three usage components. Open the synthetic contract credit. Gross is $91,250, credit $12,500, draft estimate $78,750.

## Scene 2: historical time-machine before decision
Call `python tools/snapshot_v2.py F01 2025-10-02T16:59:59Z finance`. Source evidence and draft workpaper are visible. Final October 8 vendor bill, approved workbook, actual journal are not yet available. Journal posted Oct 2 to the September accounting period: demonstrate separation of actual knowledge date vs accounting period.

## Scene 3: graph trace
Connect journal `V2-JE-ACCR-001` through `F01_approved_workpaper.xlsx / Accrual Calculation!B7` to the three usage rows and contract credit. `F01_approved_workpaper.xlsx` appears after decision time, as an approved work artifact, not in the earlier pre-decision replay.

## Scene 4: fast forward
Call `python tools/snapshot_v2.py F01 2025-10-09T16:59:59Z finance`. Final invoice $80,050 now visible, leading to $1,300 variance, and after Oct 10 the separate true-up workbook appears.

## Scene 5: exceptions
F02: two invoice deliveries but one unique logical bill; link $24,000 gross to $2,400 credit and $21,600 net.
F03: original $58,000 receivable and $57,975 bank wire have $25 difference; initially unresolved, later settled by human controller-approved fee entry.
C01: replay 2025-09-30T16:59:59Z with draft and vendor email while December final invoice remains hidden.

## Scene 6: demonstrate limits
Click an unavailable document and show the gateway denying retrieval; approval actions must be controller-gated and audit-logged, never performed directly by the agent. For the hackathon, show only a sandbox financial adjustment, not a real ERP posting.

## Metrics
Document visibility precision, future-info leakage (target zero), formula correctness, duplicate-handling accuracy, balance checks, provenance completeness, and approval enforcement. Test via `python tools/verify_v2.py`.

#!/usr/bin/env python3
"""Sample document visibility filtering; production agents must NOT see excluded_items."""
import csv,sys,json,datetime
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
def parse(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def snapshot(case_id,as_of,actor='finance'):
  with (BASE/'metadata/source_manifest.csv').open() as f: rows=list(csv.DictReader(f))
  included=[]
  for r in rows:
    if r['case_id']!=case_id:continue
    if parse(r['available_at'])<=parse(as_of) and actor in r['actor_scope'].split(','):
      included.append({'id':r['source_id'],'path':r['path'],'entity_id':r['entity_id'],'available_at':r['available_at']})
  return {'case_id':case_id,'as_of':as_of,'actor':actor,'documents':included}
if __name__=='__main__':
 case=sys.argv[1] if len(sys.argv)>1 else 'F01'
 asof=sys.argv[2] if len(sys.argv)>2 else '2025-10-02T16:59:59Z'
 role=sys.argv[3] if len(sys.argv)>3 else 'finance'
 print(json.dumps(snapshot(case,asof,role),indent=2))

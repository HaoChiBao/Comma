#!/usr/bin/env python3
"""Reproducible integrity and as-of access checks for the synthetic v2 corpus."""
import csv,json,hashlib,zipfile,collections
from decimal import Decimal
from pathlib import Path
from snapshot_v2 import snapshot
BASE=Path(__file__).resolve().parents[1]
def rows(p):
 with (BASE/p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
base=rows('structured/general_ledger_lines.csv')
assert sum(len(rows('structured/'+x.name)) for x in (BASE/'structured').glob('*.csv'))==20000
sums=collections.defaultdict(lambda:Decimal('0'))
for r in base:sums[r['journal_id']]+=Decimal(r['debit_usd'])-Decimal(r['credit_usd'])
assert len(sums)==4000 and all(v==0 for v in sums.values())
extra=rows('data_extensions/v2_journal_lines.csv')
s2=collections.defaultdict(lambda:Decimal('0'))
for r in extra:s2[r['journal_id']]+=Decimal(r['debit_usd'])-Decimal(r['credit_usd'])
assert all(v==0 for v in s2.values())
manifest=rows('metadata/source_manifest.csv');assert len(manifest)==649
new=rows('metadata_v2/new_file_manifest.csv');assert len(new)==132
assert len({r['source_id'] for r in manifest})==len(manifest)
for row in manifest:
 p=BASE/row['path'];assert p.exists(),p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
books=list((BASE/'documents/workpapers').glob('*.xlsx'));assert len(books)==43,len(books)
for book in books:
 with zipfile.ZipFile(book) as z:
  assert z.testzip() is None
  assert any(b'<x:f' in z.read(n) for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')),book
b=snapshot('F01','2025-10-02T16:59:59Z','finance')['documents']
assert any(x['entity_id']=='V2-USAGE-0925' for x in b)
assert not any(x['entity_id']=='V2-INV-CLOUD-1008' for x in b)
assert not any('approved_workpaper' in x['path'] for x in b)
assert not any('trueup_workpaper' in x['path'] for x in b)
a=snapshot('F01','2025-10-09T16:59:59Z','finance')['documents']
assert any(x['entity_id']=='V2-INV-CLOUD-1008' for x in a)
c=snapshot('C01','2025-09-30T16:59:59Z','finance')['documents']
assert not any(x['entity_id']=='INV-C01-381' for x in c)
assert any('Close_Draft_v1' in x['path'] for x in c)
f=snapshot('F03','2025-10-03T13:59:59Z','finance')['documents']
assert any(x['entity_id']=='V2-JPM-88310442' for x in f)
assert not any(x['entity_id']=='V2-JE-FEE-003' for x in f)
assert Decimal('91250')-Decimal('12500')==Decimal('78750')
assert Decimal('80050')-Decimal('78750')==Decimal('1300')
print('PASS: 20,000 baseline rows and 4,000 balanced journals; 15 balanced extension lines; 649 hashed evidence files; 43 formula workbooks; C01/F01/F03 time-isolation')

#!/usr/bin/env python3
"""Load the completely synthetic WorldState CSV corpus into SQLite for prototyping."""
import csv, sqlite3
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
DB=BASE/'worldstate_demo.sqlite'
if DB.exists(): DB.unlink()
conn=sqlite3.connect(DB)
for folder in ['structured','metadata']:
  for f in sorted((BASE/folder).glob('*.csv')):
    with f.open(encoding='utf-8',newline='') as inp:
      rows=csv.DictReader(inp); cols=rows.fieldnames
      if not cols: continue
      qname='"'+f.stem+'"'
      definitions=', '.join('"'+c+'" TEXT' for c in cols)
      conn.execute(f'CREATE TABLE {qname} ({definitions})')
      colq=', '.join('"'+x+'"' for x in cols)
      slots=', '.join('?' for _ in cols)
      insert=f'INSERT INTO {qname} ({colq}) VALUES ({slots})'
      count=0
      for rec in rows:
        conn.execute(insert,[rec[c] for c in cols]);count+=1
      print(f'{f.stem}: {count} rows')
for field, table in [('journal_id','general_ledger_lines'),('invoice_id','invoice_headers'),('po_id','purchase_order_headers'),('accrual_id','accrual_events'),('entity_id','source_manifest'),('case_id','source_manifest')]:
    conn.execute(f'CREATE INDEX IF NOT EXISTS ix_{table}_{field} ON {table}("{field}")')
conn.commit();conn.close()
print(f'Database created: {DB}')

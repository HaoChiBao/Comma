-- WorldState demonstration import schema (all records fictitious)
CREATE TABLE IF NOT EXISTS source_documents (
 source_id TEXT PRIMARY KEY, source_type TEXT NOT NULL, entity_id TEXT, case_id TEXT,
 path TEXT NOT NULL UNIQUE, document_date DATE, available_at TIMESTAMPTZ, ingested_at TIMESTAMPTZ,
 actor_scope TEXT, version INTEGER NOT NULL, sha256 TEXT NOT NULL, notes TEXT, synthetic BOOLEAN DEFAULT TRUE
);
CREATE INDEX IF NOT EXISTS ix_sources_asof ON source_documents (available_at, source_type);
CREATE INDEX IF NOT EXISTS ix_sources_entity ON source_documents (entity_id);
CREATE TABLE IF NOT EXISTS graph_edges (
 id BIGSERIAL PRIMARY KEY, source_node TEXT, target_node TEXT, edge_type TEXT, assertion_status TEXT,
 case_id TEXT, source_evidence_ref TEXT
);
CREATE TABLE IF NOT EXISTS access_audit (
 id BIGSERIAL PRIMARY KEY, actor_id TEXT, cutoff_time TIMESTAMPTZ, source_id TEXT, permitted BOOLEAN,
 reason TEXT, checked_at TIMESTAMPTZ DEFAULT now()
);
-- CSV files are canonical extracts. For a runnable application, define typed staging schemas
-- matching the CSV headers and implement an ACL-backed versioned query layer.

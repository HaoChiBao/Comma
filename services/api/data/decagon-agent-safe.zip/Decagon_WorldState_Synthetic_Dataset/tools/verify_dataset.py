#!/usr/bin/env python3
import csv,json,hashlib,collections,decimal,sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
D=decimal.Decimal
def read(p):
 with (BASE/p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
rows={x.stem:read('structured/'+x.name) for x in (BASE/'structured').glob('*.csv')}
assert sum(map(len,rows.values()))==20000
assert len(rows['general_ledger_lines'])==8000
bal=collections.defaultdict(lambda:D('0'))
for r in rows['general_ledger_lines']:bal[r['journal_id']]+=D(r['debit_usd'])-D(r['credit_usd'])
assert len(bal)==4000 and all(v==0 for v in bal.values())
inv={r['invoice_id'] for r in rows['invoice_headers']}
po={r['po_id'] for r in rows['purchase_order_headers']}
assert all(r['invoice_id'] in inv for r in rows['invoice_lines'])
assert all(r['po_id'] in po for r in rows['purchase_order_lines'])
assert all(not r['po_id'] or r['po_id'] in po for r in rows['invoice_headers'])
man=read('metadata/source_manifest.csv')
assert len(man)==517
for r in man:
 p=BASE/r['path']; assert p.is_file(),p
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
from snapshot_demo import snapshot
x=snapshot('C01','2025-09-30T16:59:59Z','finance')
assert any(i['entity_id']=='MSG-0001' for i in x['included_documents'])
assert not any(i['entity_id']=='INV-C01-381' for i in x['included_documents'])
assert len(x['visible_general_ledger_lines'])==0
assert len(x['visible_accrual_events'])==0
y=snapshot('C07','2025-09-30T16:59:59Z','finance')
assert not any(i['entity_id']=='CTR-0007' for i in y['included_documents'])
z=snapshot('C07','2025-09-30T16:59:59Z','legal')
assert any(i['entity_id']=='CTR-0007' for i in z['included_documents'])
assert any(i['entity_id']=='POL-ACC-v1' for i in snapshot('C08','2025-09-30T16:59:59Z','finance')['included_documents'])
assert not any(i['entity_id']=='POL-ACC-v2' for i in snapshot('C08','2025-09-30T16:59:59Z','finance')['included_documents'])
print('PASS: 20,000 rows, 4,000 balanced journals, FKs, 517 hashes, C01 leakage, C07 ACL, C08 policy version')

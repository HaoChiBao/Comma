#!/usr/bin/env python3
"""Example time/role filtering. Agent applications must enforce on all access paths."""
import csv, json, sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
def csvrows(path):
 with (BASE/path).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def snapshot(case_id='C01',as_of='2025-09-30T16:59:59Z',role='finance'):
 docs=[x for x in csvrows('metadata/source_manifest.csv') if x['case_id']==case_id]
 included=[{'source_id':x['source_id'],'entity_id':x['entity_id'],'source_type':x['source_type'],'available_at':x['available_at'],'path':x['path']} for x in docs if x['available_at']<=as_of and role in x['actor_scope'].split(',')]
 excluded=[{'source_id':x['source_id'],'entity_id':x['entity_id'],'reason':('future_information' if x['available_at']>as_of else 'unauthorized_role')} for x in docs if not (x['available_at']<=as_of and role in x['actor_scope'].split(','))]
 gl=[x for x in csvrows('structured/general_ledger_lines.csv') if x['case_id']==case_id and x['posted_at']<=as_of]
 acc=[x for x in csvrows('structured/accrual_events.csv') if x['case_id']==case_id and x['recorded_at']<=as_of]
 inv=[x for x in csvrows('structured/invoice_headers.csv') if x['case_id']==case_id and x['received_at']<=as_of]
 return {'case_id':case_id,'as_of':as_of,'role':role,'included_documents':included,'excluded_documents_for_auditor_only':excluded,'visible_general_ledger_lines':gl,'visible_accrual_events':acc,'visible_invoice_headers':inv,'warning':'Excluded content must not be sent to the simulated agent. Auditor-only metadata is diagnostic.'}
if __name__=='__main__':
 print(json.dumps(snapshot(sys.argv[1] if len(sys.argv)>1 else 'C01',sys.argv[2] if len(sys.argv)>2 else '2025-09-30T16:59:59Z',sys.argv[3] if len(sys.argv)>3 else 'finance'),indent=2))

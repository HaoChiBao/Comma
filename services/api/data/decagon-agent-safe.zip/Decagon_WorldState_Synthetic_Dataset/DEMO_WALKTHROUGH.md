# WorldState Demo Walkthrough — Decagon Synthetic Corpus

**All financial information below is fictional and does not describe Decagon's finances.**

## Run 0: dataset validation

```bash
python tools/verify_dataset.py
python tools/load_to_sqlite.py
```

Expected: 20,000 structured financial rows, 517 PDF/EML source documents, 4,000 balanced journals, 10 labeled cases. `worldstate_demo.sqlite` contains staging tables and provenance manifests.

## Run 1: the main time-travel demo (C01)

Use the date `2025-09-30T16:59:59Z` and actor group `finance` to reconstruct evidence for an accrual *before the accountant records it*.

```bash
python tools/snapshot_demo.py C01 2025-09-30T16:59:59Z finance
```

Expected accessible source evidence includes `PO-C01-1123` ($145), `MSG-0001` ($160 revised estimate), `SVC-0001` (service verification), and applicable policy versions. It MUST exclude the original recorded accrual of $150 (created at 17:00) and final invoice `INV-C01-381` for $158 (received December 10). The snapshot demo prints excluded IDs for **auditor-only troubleshooting**; do not send that section to a replay agent.

Move the time slider to `2025-12-15T12:00:00Z`. The invoice becomes available. Explain the $8 difference against the human's $150 accrual *retrospectively*, without pretending the later invoice was knowable in September.

## Run 2: other tests

- **C02**: An August-printed invoice arrives in October. Confirm the time filter respects receipt rather than document date.
- **C03**: Contract amendment `AMD-001` is effective September 20 but delivered October 2. It is absent from the September replay.
- **C04**: Supporting purchase order is missing from the case; the agent must say "not verified" rather than invent one.
- **C05**: Two September estimates ($6,100 and $6,800) are available and conflict. Preserve both facts and flag uncertainty.
- **C06**: `metadata/raw_erp_import_events.csv` has two source deliveries for one invoice; the logical invoice ID is only counted once.
- **C07**: `CTR-0007` is available to a legal/controller actor but denied to finance. Run `snapshot_demo.py C07 2025-09-30T16:59:59Z legal` and change `legal` to `finance`.
- **C08**: September uses `POL-ACC-v1`; October revision `POL-ACC-v2` must not govern the September decision.
- **C09**: A $300 corrective journal is posted October 7 after the September entry; both versions persist in the historical record.
- **C10**: An email embeds malicious instructions; ingest its *business evidence* without obeying its embedded directions.

## Recommended presentation flow

1. Open a case list, select C01 and inspect its linked financial records.
2. Show the graph: PO $145, estimate $160, decision $150, future invoice $158.
3. Move the as-of slider before the decision. The decision and invoice are inaccessible to the *agent*, though an auditor UI can distinguish excluded nodes.
4. Launch a historical analysis. Require all explanations to cite source IDs and prove time visibility.
5. Move the slider to December and show the final invoice and variance.
6. Open C07 to demonstrate ACL-based denial; open C05 to show contradictory evidence.
7. Finish by showing an append-only audit and an **unposted** suggested adjustment requiring human review.

## Evidence claims to avoid

Do not say the accountant definitely used a PO simply because it existed. Do not claim this dataset is audited financial reporting or actual Decagon records. Do not claim any simulated correction was posted to a real ERP. Do not expose the `oracle/` directory or excluded source content to the evaluation agent.

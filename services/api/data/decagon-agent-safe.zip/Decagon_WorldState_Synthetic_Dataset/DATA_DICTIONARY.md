# Dataset Data Dictionary

All files are synthetic simulation assets. Amounts are USD decimal strings; timestamps are UTC ISO 8601 strings unless a date-only column is named.

## Structured financial CSVs (20,000 rows)

| Table | Rows | Grain | Primary ID | Key joins |
|---|---:|---|---|---|
| `general_ledger_lines.csv` | 8,000 | One debit or credit line | `line_id` | `journal_id`, `source_ref`, `case_id` |
| `invoice_headers.csv` | 2,000 | One AP invoice | `invoice_id` | `vendor_id`, optional `po_id` |
| `invoice_lines.csv` | 2,000 | One invoice detail line | `line_id` | `invoice_id` |
| `purchase_order_headers.csv` | 1,250 | One purchase order | `po_id` | `vendor_id` |
| `purchase_order_lines.csv` | 1,250 | One PO line | `po_line_id` | `po_id` |
| `bank_transactions.csv` | 2,000 | One bank feed item | `bank_tx_id` | optional `linked_invoice_id` |
| `accrual_events.csv` | 1,500 | One accrual or reversal event | `record_id` | `accrual_id`, optional `linked_journal_id` |
| `finance_audit_events.csv` | 1,500 | One finance review or approval activity | `event_id` | `actor_id`, `resource_id` |
| `master_data.csv` | 500 | One vendor, account, actor, cost center, or customer | `record_id` | typed `record_type` |

**Sum: 20,000 rows.** There are 4,000 journal entries, each with two balanced lines. `POSTED` and `DRAFT` statuses are both present; bank statements intentionally include unmatched records.

## Source documents (517 files)

| Folder | Format | Approx. contents |
|---|---|---|
| `documents/invoices` | PDF | Vendor bills, due terms, amounts, receipt dates |
| `documents/purchase_orders` | PDF | Authorized commitments and reference IDs |
| `documents/emails` | EML | Vendor pricing revisions and conflicts |
| `documents/service_confirmations` | PDF | Evidence that recurring services were delivered |
| `documents/contracts` | PDF | Pricing agreements and amendments |
| `documents/policies` | PDF | Simulated finance and access-control policy versions |
| `documents/payment_advices` | PDF | A subset of bank/payment remittance details |

`metadata/source_manifest.csv` is the join bridge from file paths to source IDs and financial entity IDs. `sha256` proves file integrity. `available_at` governs when the source can appear in historical queries. `actor_scope` further constrains access.

`metadata/mailbox_delivery_events.csv` gives explicit mail delivery times. `metadata/raw_erp_import_events.csv` intentionally includes duplicated raw records in C06. `metadata/preview_*.json` are demonstration previews.

## Model of time and evidence

- **Document date:** date printed or nominally effective on a source.
- **Available at:** when the source was delivered/accessible to the organization (with actor scope).
- **Ingested at:** when WorldState copied that source into its warehouse.
- **Posted/recorded at:** when the accounting record was entered. A pre-decision replay must not read a record merely because its *effective* date is earlier.
- **Evidence edges:** `POTENTIALLY_SUPPORTS` means a source might explain an amount; it is not proof that a particular human read that source.

## Synthetic-data limitations

The data is intentionally AP/expense/accrual focused and is not a full consolidated general ledger including payroll, revenue recognition, taxes, or complete financial statements. Transaction histories and document availability are generated coherently for replay use, but are simplified relative to live production ERPs. Some PDFs use a common template; this is a functional test corpus, not a forensic replica of external vendors' real documents.

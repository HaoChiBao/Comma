# Decagon / WorldState — Synthetic Financial Evidence Dataset

> **FICTIONAL DEMO DATA. NOT DECAGON FINANCIAL RECORDS.** No affiliation, endorsement, or actual internal company information is implied. Decagon is a real AI company; this bundle is an invented example of a company selling enterprise conversational AI products.

## Dataset scope

- **20,000 structured financial rows**, across 9 CSV tables. Rows are not all distinct economic transactions; they include headers, lines, journal lines, and events.
- **517 source documents**, in PDF and EML formats.
- **10 investigated finance scenarios**, with relationships and known hidden outcomes.
- **A simulated 2025 financial year**, including invoices and payment settlement extending into early 2026; 2026 ingestion timestamps represent later capture into WorldState.
- **No iMessage dependency**. Uses a web-first demonstration workflow.

## Contents

`structured/` - general ledger line items, invoices, purchase orders, bank feed, accrual events, audit events, master data

`documents/` - vendor invoices, purchase orders, service confirmations, contracts, policy versions, vendor emails, payment advices

`metadata/` - exact source-level availability timestamps, actor scopes, content hashes, intake manifest, case registry and verification report

`graph/` - JSONL typed evidence nodes/edges with `POTENTIALLY_SUPPORTS`, `CONTRADICTS`, `SUPERSEDES`, `GOVERNS`, `CORRECTS`, `RECONCILES_WITH`

`oracle/` - **evaluation-only** answers. Do not expose to the agent being evaluated.

## Important time semantics

- `invoice_date` is the vendor-printed date; **not proof the invoice was available then**.
- `received_at` / `available_at` is source arrival / availability as simulated.
- `ingested_at` is the time WorldState later copied the source.
- Historical role permissions must be checked separately; a document can exist but remain restricted.
- Replay at `2025-09-30T16:59:59Z` must also hide the historical `2025-09-30T17:00:00Z` answer and later corrective entries.
- Relationships labeled `POTENTIALLY_SUPPORTS` **do not establish actual human use**.
- Contracts and policies must be versioned as available, not merely by effective dates.

## Primary case C01

Vendor PO USD 145 (September 12), revised estimate email USD 160 (September 25), accountant accrues USD 150 (September 30), final invoice USD 158 received December 10. The AI replay before the decision sees the former documents, **not the accrual itself or the invoice**. Retrospective investigation may see both.

## Source conventions

Every PDF includes a conspicuous fictional-data warning, and every email has an explicit synthetic-training header and `.example` domains. Vendors, staff, amounts, timestamps and business events are fabricated; financial ratios must not be attributed to the real Decagon.

## Usage

1. Run `python tools/load_to_sqlite.py` for a ready-to-query local SQLite database, or ingest the CSVs into your PostgreSQL staging schemas. `tools/schema.sql` is a starting point for production-facing document and graph tables.
2. Ingest `metadata/source_manifest.csv` and import files from `documents/`, preserving hashes and paths.
3. Use `document_availability_events.csv` and historical actor scopes for time-filtering.
4. Build the graph from `graph/*.jsonl`; document source relationships must be verifiable.
5. Keep `oracle/` completely separate from agent retrieval and application reads.
6. Run `python tools/verify_dataset.py` for integrity tests. Use `python tools/snapshot_demo.py C01 2025-09-30T16:59:59Z finance` to inspect pre-decision visibility. The `excluded_documents_for_auditor_only` section must **never** be returned to the replay agent.
7. Demo a pre-decision replay of C01, a retrospective investigation, a role-access denial C07, and version control C03/C08.

## Quality caveats

- This dataset is coherent as a **simulation**, not a complete consolidation/ERP close or audited financial statement.
- Many background structured transactions have no printable source document; this mirrors mixed enterprise systems.
- Bank feed has intentionally unmatched items and accruals include draft/scheduled events.
- Legal/accounting policies are examples, not real compliance advice.
- Source permissions are simplified actor-scope labels, not a substitute for complete production authorization history.
- The generator is deterministic. Rebuild: `python tools/generate.py` from a development checkout after adjusting the `BASE` output path.

## Development utilities

- `tools/load_to_sqlite.py`: load all financial and provenance CSVs into SQLite.
- `tools/snapshot_demo.py`: sample case-local time/ACL query for prototyping.
- `tools/verify_dataset.py`: assert double-entry balance, source checksums, joins, time travel, and permissions.
- `metadata/preview_C01_before_accrual.json`, etc.: expected demonstration snapshots.
- `tools/generate.py`: deterministic source generator (recreates the entire dataset; run only intentionally).
